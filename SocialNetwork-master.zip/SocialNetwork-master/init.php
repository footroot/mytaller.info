<?php
// ATTENTION !!!!
// please include only files if you know how the
// autoloader works, usealy there is no need for that
include_once("vendor/autoload.php");
include_once("routing.php");
