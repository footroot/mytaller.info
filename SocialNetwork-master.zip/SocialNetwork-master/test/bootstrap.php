<?php
/**
 *
 * @author j
 * Date: 10/7/15
 * Time: 10:26 PM
 *
 * File: boostrap.php
 */
require_once 'vendor/autoload.php';