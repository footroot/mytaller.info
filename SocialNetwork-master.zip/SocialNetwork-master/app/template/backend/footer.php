        </div>
    </div>
</div>


    <?php
    foreach($footer as $script)
        echo $script;
    ?>
</body>
</html>