<html>
    <body>
        <p>Please validate following content:</p>

        <a href="<?php echo $url; ?>"><?php echo $url; ?></a>

        <br/>
        Happy Hacking
        <br/>
        Bot
    </body>
</html>