import Home from '@/pages/Home'

export default {
  path: '/',
  name: 'Home',
  component: Home
}
