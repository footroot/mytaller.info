import Details from '@/pages/Details'

export default {
  path: '/details/:id',
  name: 'Details',
  component: Details
}
