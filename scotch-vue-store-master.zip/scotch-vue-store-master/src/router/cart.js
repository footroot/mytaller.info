import Cart from '@/pages/Cart'

export default {
  path: '/cart',
  name: 'Cart',
  component: Cart
}
