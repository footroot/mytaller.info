export const API_BASE = 'https://scotch-vue-shop-api.herokuapp.com/api/v1'
// export const API_BASE = 'http://localhost:9000/api/v1'
